/* ── NAVBAR SCROLL ── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 40);
});

/* ── HAMBURGER ── */
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');
hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));

/* ── TYPEWRITER ── */
const phrases = [
  'Data Analyst',
  'Business Analyst',
  'IT Project Support',
  'Power BI Developer',
  'AI Enthusiast'
];
let pi = 0, ci = 0, deleting = false;
const el = document.getElementById('typedText');

function type() {
  const word = phrases[pi];
  el.textContent = deleting ? word.slice(0, ci--) : word.slice(0, ci++);
  let delay = deleting ? 60 : 110;
  if (!deleting && ci > word.length)      { delay = 1800; deleting = true; }
  else if (deleting && ci < 0)            { deleting = false; pi = (pi + 1) % phrases.length; ci = 0; delay = 400; }
  setTimeout(type, delay);
}
type();

/* ── PARTICLES ── */
const container = document.getElementById('particles');
for (let i = 0; i < 28; i++) {
  const p = document.createElement('div');
  p.className = 'particle';
  const size = Math.random() * 4 + 2;
  p.style.cssText = `
    width:${size}px; height:${size}px;
    left:${Math.random() * 100}%;
    animation-duration:${Math.random() * 14 + 10}s;
    animation-delay:${Math.random() * 10}s;
    opacity:0;
  `;
  container.appendChild(p);
}

/* ── FADE-IN OBSERVER ── */
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); } });
}, { threshold: 0.12 });

document.querySelectorAll(
  '.skill-card, .project-card, .timeline-item, .cert-card, .about-grid, .contact-grid'
).forEach(el => { el.classList.add('fade-in'); observer.observe(el); });

/* ── ACTIVE NAV LINK ── */
const sections = document.querySelectorAll('section[id]');
const navAs    = document.querySelectorAll('.nav-links a');
window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 120) current = s.id;
  });
  navAs.forEach(a => {
    a.style.color = a.getAttribute('href') === `#${current}` ? 'var(--accent)' : '';
  });
});

/* ── CONTACT FORM ── */
document.getElementById('contactForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const btn = this.querySelector('button[type="submit"]');
  btn.innerHTML = '<i class="fas fa-check"></i> Sent! (Connect Formspree to enable)';
  btn.disabled = true;
  btn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
  setTimeout(() => {
    btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
    btn.disabled = false;
    btn.style.background = '';
    this.reset();
  }, 3000);
});
