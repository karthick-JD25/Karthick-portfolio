# 🚀 Karthick J D — Professional Portfolio

A clean, dark-themed, fully responsive personal portfolio website built with **pure HTML, CSS, and JavaScript** — no frameworks, no build tools, zero dependencies.

🔗 **Live Demo:** [karthick-analyst-showcase.lovable.app](https://karthick-analyst-showcase.lovable.app)

---

## 📁 Project Structure

```
portfolio/
├── index.html          # Main HTML — all sections
├── css/
│   └── style.css       # All styles (dark theme, responsive)
├── js/
│   └── main.js         # Typewriter, particles, scroll, form
├── assets/
│   └── Karthick_JD_Resume.pdf   ← Add your resume PDF here
└── README.md
```

---

## ✨ Features

- **Animated hero** with typewriter effect and floating particles
- **Smooth scroll** + active nav highlight
- **Fade-in animations** on scroll via Intersection Observer
- **Fully responsive** — mobile, tablet, desktop
- **Dark futuristic theme** with gradient accents
- Sections: About, Skills, Projects, Experience, Certifications, Contact
- Contact form (wire up to [Formspree](https://formspree.io) — see below)

---

## 🔧 Setup & Deployment

### 1. Clone or Download
```bash
git clone https://github.com/karthick-JD25/portfolio.git
cd portfolio
```

### 2. Add Your Resume
Place your resume PDF at:
```
assets/Karthick_JD_Resume.pdf
```

### 3. Run Locally
Just open `index.html` in your browser — no server needed.

### 4. Deploy to GitHub Pages
```bash
# In your repo settings → Pages → Source: main branch / root
```
Your site will be live at: `https://karthick-JD25.github.io/portfolio`

---

## 📬 Enable Contact Form (Formspree)

1. Go to [formspree.io](https://formspree.io) and create a free account.
2. Create a new form — copy your endpoint URL (e.g. `https://formspree.io/f/xyzabcde`).
3. In `index.html`, update the form tag:
```html
<form class="contact-form" id="contactForm" action="https://formspree.io/f/YOUR_ID" method="POST">
```
4. In `js/main.js`, replace the fake submit handler with a real fetch/redirect.

---

## 🛠 Customization

| What to change | Where |
|---|---|
| Name, bio, links | `index.html` — hero & about sections |
| Projects | `index.html` — `#projects` section |
| Skills | `index.html` — `#skills` section |
| Colors / theme | `css/style.css` — `:root` CSS variables |
| Typewriter phrases | `js/main.js` — `phrases` array |
| Resume PDF | `assets/Karthick_JD_Resume.pdf` |

---

## 📜 License

MIT — free to use, customize, and share.

---

*Built by Karthick J D · Chennai, India · 2025*
